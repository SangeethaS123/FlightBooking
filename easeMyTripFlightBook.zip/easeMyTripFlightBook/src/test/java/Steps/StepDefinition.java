package Steps;

import java.io.File;
import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.Duration;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collections;
import java.util.List;
import java.util.NoSuchElementException;


import org.apache.commons.io.FileUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.ElementNotInteractableException;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.edge.EdgeOptions;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import io.cucumber.java.After;
import io.cucumber.java.Before;
import io.cucumber.java.en.And;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.github.bonigarcia.wdm.WebDriverManager;
import lombok.extern.log4j.Log4j;

public class StepDefinition {

public RemoteWebDriver driver;



@Before public void setUp() throws InterruptedException{ 

	
System.setProperty("webdriver.http.factory", "jdk-http-client");

WebDriverManager.edgedriver().clearDriverCache().setup();

WebDriverManager.edgedriver().setup();

EdgeOptions option= new EdgeOptions();

driver = new EdgeDriver();

option.addArguments("--remote-all-origins=*");

option.addArguments("--disable-notifications");

option.addArguments("--guest");

Thread.sleep(4000);

}

@Given("Load the booking URL and Maximize")

public void loadBookingURL() throws InterruptedException {

driver.get("http://www.easemytrip.com");

driver.manage().window().maximize();

Thread.sleep(3000);

}

@And("Click on SignIn button")

public void SignInbutton() throws InterruptedException {

Actions act = new Actions(driver);
WebElement LoginBtn = driver.findElement(By.className("_btnclick"));
WebElement CustLogin = driver.findElement(By.xpath("//span[text()='Customer Login']"));
act.moveToElement(LoginBtn).click(CustLogin).perform();
//((RemoteWebDriver) driver).executeScript("arguments[0].click();",signIn);

Thread.sleep(3000);

}

@And("Enter the PhoneOrMail as (.*)$")

public void phoneOrMail(String uname) throws InterruptedException {

WebElement mobmail = driver.findElement(By.id("txtEmail"));

// ((RemoteWebDriver) driver).executeScript("arguments[0].value='kivikrish@yahoo.com'",email);

mobmail.sendKeys(uname);

Thread.sleep(3000);

}

@And("Click on Continue button")

public void emailEntryClick() throws InterruptedException {
	
	WebDriverWait wait = new WebDriverWait(driver,Duration.ofSeconds(30));
	wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("shwotp")));
	WebElement Contnu = driver.findElement(By.id("shwotp"));
	((RemoteWebDriver) driver).executeScript("arguments[0].click();",Contnu);

	try {
		Thread.sleep(8000);
		driver.findElement(By.id("shwotp")).click();
	} catch (ElementNotInteractableException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	
}

@And("Click And Enter the Password as (.*)$")

public void Password(String Pwd) throws InterruptedException {

Thread.sleep(4000);

WebElement PasswrdButtn = driver.findElement(By.id("shwlgnbx"));

PasswrdButtn.click();

WebElement Passwrd = driver.findElement(By.xpath("//input[@type='password']"));
Passwrd.clear();
Passwrd.sendKeys(Pwd);

//Thread.sleep(3000);

}

@And("Click on Login button")

public void LoginButton() {

	driver.findElement(By.xpath("(//input[@name='btn_Login'])[2]")).click();

}

@And("Take ScreenShot")

public void ScreenShot() throws InterruptedException, IOException {

File source = driver.getScreenshotAs(OutputType.FILE);

File dest = new File("./snaps/timelog.png");

FileUtils.copyFile(source, dest);

}

@Then("Select From Location as (.*)$")

public void fromLocation(String frLoc) throws InterruptedException {
	
	Thread.sleep(3000);
	
	
	WebElement startLoc = driver.findElement(By.xpath("//input[@id='FromSector_show']"));
	((RemoteWebDriver) driver).executeScript("arguments[0].click();",startLoc);
	Thread.sleep(3000);
	//startLoc.click();
	driver.findElement(By.xpath("//input[@id='a_FromSector_show']")).sendKeys(frLoc);
	Thread.sleep(3000);
	driver.findElement(By.xpath("(//span[@class='flsctrhead'])[1]")).click();

}




@And("Select To Location as (.*)$")
public void toLocation(String toLoc) throws InterruptedException {
	
	WebElement destLoc = driver.findElement(By.xpath("(//input[@placeholder='To'])[3]"));
	//(//input[@class='srctinput autoFlll'])[2]
	destLoc.sendKeys(toLoc);
	Thread.sleep(3000);
	driver.findElement(By.xpath("(//span[@class='flsctrhead'])[2]")).click();
}


@And("Select Departure Date")

public void departureDate() throws InterruptedException, ParseException {
	//driver.findElement(By.id("ddate")).click();
	
	String expectedDate = "25/04/2024"; //dd/mm/yyyy
	String[] dateVal = expectedDate.split("/");
	
	//Retrieve year
	int yearToSelect = Integer.parseInt(dateVal[2]);
	
	Calendar cal = Calendar.getInstance();
	int currentYear = cal.get(Calendar.YEAR);
	System.out.println("Current Year: "+currentYear);
	
	//Retrieve month 
	 int monthToSelect = Integer.parseInt(dateVal[1]);
	 
	 //find month of the year
	 String selectedMonth = driver.findElement(By.xpath("//div[@class='month']")).getText();
	 System.out.println("Current Month: "+selectedMonth);
	 Thread.sleep(500);
	 
	 //Select format of month Calendar to text
	 SimpleDateFormat inputFormat = new SimpleDateFormat("MMMM"); //January - December
	 cal.setTime(inputFormat.parse(selectedMonth));
	 
	 //Convert month name to month number
	 SimpleDateFormat outputFormat = new SimpleDateFormat("MM");
	 System.out.println("Month to Number :"+outputFormat.format(cal.getTime()));
	 
	 int presentMonth = Integer.parseInt(outputFormat.format(cal.getTime()));
	 System.out.println("Present Month : "+presentMonth);
	
	//Logic to select date by month
	 //forward direction
	 if(monthToSelect > presentMonth) { 
		 for (int i = 0; i < monthToSelect-presentMonth; i+=2) 
		 driver.findElement(By.xpath("(//img[@alt='Arrow'])[2]")).click();
		 Thread.sleep(1000);
		 }
	
	//select date
	 WebElement dateSelected = driver.findElement(By.xpath("(//li[contains(text(),"+dateVal[0]+")])[1]"));
	 dateSelected.click();
	 
}

@Then("Click on Search")
public void Click_on_Search() {
	driver.findElement(By.className("srchBtnSe")).click();
}

@And("Find Cheap Flight Fare")
	public void Find_Cheap_Flight_Fare() throws InterruptedException{
	Thread.sleep(6000);
	List<WebElement> allPrice = driver.findElements(By.xpath("(//div[contains(@class,'col-md-10 col-sm-8')]//span)"));
	System.out.println("Total no of price counts:"+allPrice);
	List<Integer> priceList1 = new ArrayList<Integer>();
	for (WebElement eachPrice : allPrice) {
		System.out.println(eachPrice.getText());
		
		String text = eachPrice.getText().replace(",", "");
		//String replace=text.replace(",", "");
		
		int price = Integer.parseInt(text);
		priceList1.add(price);
	}
		Collections.sort(priceList1);
		System.out.println("Least Price: "+priceList1.get(0));
	
		
}

	
@After public void TearDown(){ 
    driver.close(); 
 } 
	}

